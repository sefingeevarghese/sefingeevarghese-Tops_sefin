// PROGRAM 11 : FIND CIRCUMFERENCE OF SQUARE - (START) -------------------->
#include<stdio.h>
void main(){
    float circumference, a;

    printf("Enter the Side : ");
    scanf("%f", &a);

    circumference = 4 * a;  // FORMULA
    printf("circumference of Square is %.2f", circumference);
}
// PROGRAM 11 : FIND CIRCUMFERENCE OF SQUARE - (END) <--------------------