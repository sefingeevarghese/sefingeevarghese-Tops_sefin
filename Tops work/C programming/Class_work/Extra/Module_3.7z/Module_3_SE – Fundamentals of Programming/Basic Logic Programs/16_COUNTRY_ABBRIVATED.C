// PROGRAM 16 : COUNTRY'S NAME IN ABBRIVATED FORM  - (START) -------------------->
#include<stdio.h>
void main(){

    printf("Country's Name in Abbreviate Form.\n");
    printf("India : IND\n");
    printf("Canada : CAN\n");
    printf("United States of America : USA\n");
    printf("Kenya : KEN\n");
    printf("Australia : AUS");
}
// PROGRAM 16 : COUNTRY'S NAME IN ABBRIVATED FORM  - (START) -------------------->