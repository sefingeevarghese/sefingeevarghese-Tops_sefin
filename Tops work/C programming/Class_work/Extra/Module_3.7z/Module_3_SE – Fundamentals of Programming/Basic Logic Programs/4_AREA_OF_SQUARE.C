// PROGRAM 4 : FIND AREA OF SQUARE - (START) -------------------->
#include<stdio.h>
void main(){
    float area, a;

    printf("Enter the side : ");
    scanf("%f", &a);

    area = a * a;  // FORMULA
    printf("Area of Square is %.2f", area);
}
// PROGRAM 4 : FIND AREA OF SQUARE - (END) <--------------------