// PROGRAM 14 : FIND CHARACTER TO ASCII VALUE - (START) -------------------->
#include<stdio.h>
void main(){
    int n;

    printf("Enter the ASCII value : ");
    scanf("%d", &n);

    printf("Character of %d is %c.", n, n);
}
// PROGRAM 14 : FIND CHARACTER TO ASCII VALUE - (END) -------------------->