// PROGRAM 12 : FIND REQUIRED APPLES - (START) -------------------->
#include<stdio.h>
void main(){
    int apple=5, students, total;

	printf("Need to Give 5 Apples to each Students");
    printf("\nEnter the number of Students : ");
    scanf("%d", &students);

    total = apple * students;
    printf("Total %d Apples are Required.", total);
}
// PROGRAM 12 : FIND REQUIRED APPLES - (END) <--------------------