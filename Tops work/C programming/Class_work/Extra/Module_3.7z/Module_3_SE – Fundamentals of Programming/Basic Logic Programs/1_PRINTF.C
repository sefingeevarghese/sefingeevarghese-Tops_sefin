// PROGRAM 1 : DISPLAY THE INFORMATION USING PRINTF - (START) -------------------->
#include<stdio.h>
void main(){
    printf("Udit Rana");
    printf("15-12-2005");
    printf("Age is 18");
    printf("Maninagar, Ahmedabad");
}
// PROGRAM 1 : SIMPLE CALCULATOR - (END) <--------------------